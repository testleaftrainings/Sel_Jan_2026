package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition {
	public ChromeDriver driver;

	@Given("Launch the browser")
	public void launchBrowser() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@And("Load the url")
	public void loadUrl() {
		driver.get("http://leaftaps.com/opentaps");
	}

	@And("Enter the username as Demosalesmanger")
	public void enterUsername() {
		driver.findElement(By.id("username")).sendKeys("Demosalesmanager");
	}

	@And("Enter the password as crmsfa")
	public void enterPassword() {
		driver.findElement(By.id("password")).sendKeys("crmsfa");
	}

	@When("Click on the Login button")
	public void clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should be navigate to home page")
	public void verifyLogin() {
		System.out.println("Loggedin successful");
	}

}
