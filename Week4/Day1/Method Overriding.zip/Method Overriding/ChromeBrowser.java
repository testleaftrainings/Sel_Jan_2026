package week4.day1;

public class ChromeBrowser {
	
	public void launchBrowser() {
		System.out.println("Chrome browser launched");
    }
	
	public static void main(String[] args) {
		ChromeBrowser chromeOpt=new ChromeBrowser();
		chromeOpt.launchBrowser();
	}

}
