package week4.day1;

public abstract class HDFC implements RBI {
	
	//Both implemented and unimplemented method
	
	//abstract
	public abstract void carLoan();
	 
	public void setPersonalLoan() {
	System.out.println("50 L");	
	}
	
}
