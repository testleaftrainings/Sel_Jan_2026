package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import steps.BaseClass;
@CucumberOptions(features = "src/main/java/features",glue={"steps"},monochrome=true,publish=true, tags="@Smoke or @Sanity")
public class RunnerClass extends BaseClass {

}

//and     tag1   and   tag2    -both

//or      tag1   or    tag2     -either