package steps;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDefinition extends BaseClass {
	

   @And("Enter the username as {string}")
	public void enterUsername(String username) {
		driver.findElement(By.id("username")).sendKeys(username);
	}
	@And("Enter the password as {string}")
	public void enterPassword(String password) {
		driver.findElement(By.id("password")).sendKeys(password);
	}
	@And("Enter the password as crm")
	public void enterInvalidPassword() {
		driver.findElement(By.id("password")).sendKeys("crm");
	}

	@When("Click on the Login button")
	public void clickLoginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("It should be navigate to home page")
	public void verifyLogin() {
		System.out.println("Loggedin successful");
	}
	@But("It throws error message")
	public void verifyErrorMessage() {
		System.out.println("It throws error message");

	}

}
