package base;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	
	//public ChromeDriver driver;
	private static final ThreadLocal<ChromeDriver> driver= new ThreadLocal<ChromeDriver>();
	
	public void set() {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("guest");
		driver.set(new ChromeDriver(options));

	}
	
	public ChromeDriver get() {
		
		ChromeDriver chromeDriver = driver.get();
		return chromeDriver;
	}
	
	
	public String filename;
	@BeforeMethod
	public void preConditions() {
		
		set();
		//driver = new ChromeDriver(options);
		get().manage().window().maximize();
		get().get("http://leaftaps.com/opentaps");

	}
	@AfterMethod
	public void postConditions() {
	get().close();

	}
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcel.readData(filename);

	}

}
