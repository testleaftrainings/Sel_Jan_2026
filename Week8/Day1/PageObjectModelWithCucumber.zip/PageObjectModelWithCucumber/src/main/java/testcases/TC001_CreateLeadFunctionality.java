package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC001_CreateLeadFunctionality extends BaseClass {
	@BeforeTest
	public void setValues() {
		filename="CreateLead";

	}
	
	
	
	@Test(dataProvider = "fetchData")
	public void createLead(String username, String password, String companyname, String firstname, String lastname) {
		LoginPage lp=new LoginPage();   //abcd
		lp.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfaLink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyname(companyname)
		.enterFirstname(firstname)
		.enterLastname(lastname)
		.clickCreateLeadButton()
		.verifyLead();
		
		

	}

}
