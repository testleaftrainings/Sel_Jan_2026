package learnreports;

public class LearnrandomNumber {

	public static void main(String[] args) {
		int randomNumber = (int)(Math.random()*999999+99999);
		System.out.println(randomNumber);

	}

}

//0.040032748544951646                      image456555545.png
//                                          image676676677.png